export enum NegocioStatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
}
