export enum UserType {
  OWNER = 'OWNER',
  CLIENT = 'CLIENT',
}
